<html>
    <body>
        <a href = "../../Index/index.php">Home</a><br>
        <a href = "../Gestione_Dati_Globali/gestione_dati_globali.php">Gestione Dati Globali</a><br>
        <a href = "../Gestione_Dati_Propri/gestione_dati_propri.php">Gestione Dati Propri</a><br>
        <a href = "../Gestione_Struttura/gestione_struttura.php">Gestione Struttura</a><br>
    </body>
</html>