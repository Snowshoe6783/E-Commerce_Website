<?php
    header("location: Pagine/Index/index.php")
?>